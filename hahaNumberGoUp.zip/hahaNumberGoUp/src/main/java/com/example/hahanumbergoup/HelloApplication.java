package com.example.hahanumbergoup;
//-----------------------------------------------------------//Import statements\\-------------------------------------------------------------------------\\
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.HPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
//--------------------------------------------------------------//Main Class\\-----------------------------------------------------------------------------\\
public class HelloApplication extends Application {
//------------------------------------------------------------//Object creation\\--------------------------------------------------------------------------\\
    // Instance of classes
    Clicked clicked = new Clicked();
    Timer timer = new Timer();
//---------------------------------------------------//Node creation for Landing stage\\-------------------------------------------------------------------\\
    // Nodes for Landing stage
    Label lblLandingTitle = new Label("Haha Number Go Up!");
    Label lblQuote = new Label();
    Button btnLaunch = new Button("Load Game");
    Button btnNewGame = new Button("New Game");
//------------------------------------------------------//Node creation for Main stage\\-------------------------------------------------------------------\\
    // Nodes for Main stage
    Label lblTotal = new Label();
    Label lblIncrement = new Label();
    Label lblAutoIncrement = new Label();
    Label lblTitle = new Label("Haha Number Go Up!");
    Label lblAutoSaveTimer = new Label();
    Label lblTime = new Label();
    Label lblCountdown = new Label();
    ProgressBar prgHealthBar = new ProgressBar(10);
    Button btnDamage = new Button("Do some damage!");
    Button btnClickMe = new Button("Click me!");
    Button btnUpgrade = new Button("Extra Click: 10 clicks");
    Button btnAuto = new Button("Auto Click: 500 clicks");
    Button btnAutoUpgrade = new Button("Extra Auto Click: 1000 clicks");
    Button btnSettings = new Button("Settings");
//---------------------------------------------------//Node creation for Settings stage\\------------------------------------------------------------------\\
    // Nodes for Settings stage
    Label lblSettingsTitle = new Label("SETTINGS");
    Button btnHome = new Button("Back");
    Button btnSave =  new Button("Save Game");
//--------------------------------------------------------------//Start Method\\---------------------------------------------------------------------------\\
    @Override
    public void start(Stage mainStage) throws FileNotFoundException {
        // Grid parameters and constraints
        int rowCount = 22; int columnCount = 10;
        RowConstraints rc = new RowConstraints(); rc.setPercentHeight(5);
        ColumnConstraints cc = new ColumnConstraints(); cc.setPercentWidth(20);
        // Node font variables
        String fonts = "-fx-font: normal bold 15px 'Arial'";
        String titleFonts = "-fx-font: normal bold 30px 'Arial'";
        String labelFonts = "-fx-font: normal bold 20px 'Arial'";
//----------------------------------------------------------//Set style for nodes\\------------------------------------------------------------------------\\
        // Style for landing page
        lblLandingTitle.setStyle(labelFonts);
        lblQuote.setStyle(labelFonts); lblQuote.setWrapText(true);
        btnLaunch.setStyle(fonts);
        btnNewGame.setStyle(fonts);
        // Style for main page
        lblTotal.setStyle(labelFonts);
        lblIncrement.setStyle(labelFonts);
        lblAutoIncrement.setStyle(labelFonts);
        lblTitle.setStyle(labelFonts);
        lblAutoSaveTimer.setStyle(labelFonts);
        lblTime.setStyle("-fx-font: normal bold 15px 'Arial'");
        lblCountdown.setStyle("-fx-font: bold 15px 'Arial'");
        btnDamage.setStyle(fonts);
        btnClickMe.setStyle(fonts);
        btnUpgrade.setStyle(fonts);
        btnAuto.setStyle(fonts);
        btnAutoUpgrade.setStyle(fonts);
        btnSettings.setStyle(fonts);
        // Hide nodes that will be used later
        btnAuto.setVisible(false); btnUpgrade.setVisible(false); btnAutoUpgrade.setVisible(false);
        // Style for settings page
        lblSettingsTitle.setStyle(titleFonts);
        btnHome.setStyle(fonts);
        btnSave.setStyle(fonts);
//-----------------------------------------------------//Creation of Stages and scenes\\-------------------------------------------------------------------\\
        // Pane creation
        GridPane landingPane = new GridPane();
        GridPane Maingpane = new GridPane();
        GridPane settingsGPane = new GridPane();
        // Create grid for landingPane
        for (int i = 0; i < rowCount; i++) {landingPane.getRowConstraints().add(rc);}
        for (int i = 0; i < columnCount; i++) {landingPane.getColumnConstraints().add(cc);}
        // Create grid for Maingpane
        for (int i = 0; i < rowCount; i++) {Maingpane.getRowConstraints().add(rc);}
        for (int i = 0; i < columnCount; i++) {Maingpane.getColumnConstraints().add(cc);}
        // Create grid for settingsGPane
        for (int i = 0; i < rowCount; i++) {settingsGPane.getRowConstraints().add(rc);}
        for (int i = 0; i < columnCount; i++) {settingsGPane.getColumnConstraints().add(cc);}
        // Show gridlines for panes (TURN OFF EVENTUALLY!!!!!)
        landingPane.setGridLinesVisible(true);
        Maingpane.setGridLinesVisible(true);
        settingsGPane.setGridLinesVisible(true);
//----------------------------------------------------//Create and load the Landing scene\\----------------------------------------------------------------\\
        // Create and load landing scene
        Scene landingScene = new Scene(landingPane, 1280, 700);
        Stage landingStage = new Stage();
        landingStage.setTitle("Haha Number go up");
        landingStage.setScene(landingScene);
        landingStage.setResizable(false);
        landingStage.show();
        if (!checkSave()){btnLaunch.setDisable(true);}
        callQuote();
//--------------------------------------------------//Create and load the Settings scene\\-----------------------------------------------------------------\\
        // Create and load settings scene
        Stage settingsStage = new Stage();
        Scene settingsScene = new Scene(settingsGPane, 1280, 700);
        settingsStage.setTitle("Settings");
        settingsStage.setScene(settingsScene);
        settingsStage.setResizable(false);
//----------------------------------------------------//Create and load the Main scene\\-------------------------------------------------------------------\\
        // Create and load main scene
        Scene mainScene = new Scene(Maingpane, 1280, 700);
        mainStage.setTitle("Haha Number go up");
        mainStage.setScene(mainScene);
        mainStage.setResizable(false);
//----------------------------------------------------------//Timelines for Main page\\--------------------------------------------------------------------\\
        // Timeline to check if total is less than cost for upgrade buttons
        Timeline checkTotal = new Timeline(new KeyFrame(Duration.millis(1), ev -> {
            if (clicked.total < clicked.cost) {btnUpgrade.setDisable(true);}
            else{
                btnUpgrade.setVisible(true); btnUpgrade.setDisable(false);
            }
            if (clicked.total < clicked.autoCost) {btnAutoUpgrade.setDisable(true);}
            else{
                btnAutoUpgrade.setVisible(true); btnAutoUpgrade.setDisable(false);
                btnAutoUpgrade.setText("Auto click " + (clicked.autoIncrement + 1) + "x: " + clicked.autoCost + " clicks");
            }
        }));
        // Timeline for time played

//------------------------------------------------------//Save game on window close\\----------------------------------------------------------------------\\
        mainStage.setOnCloseRequest(windowEvent -> {
            try {createSave(createFile());}
            catch (FileNotFoundException e) {e.printStackTrace();}
            timer.cancel();
        });
        settingsStage.setOnCloseRequest(windowEvent -> {
            try {createSave(createFile());}
            catch (FileNotFoundException e) {e.printStackTrace();}
            timer.cancel();
        });
//----------------------------------------------------//Button events for landingStage\\-------------------------------------------------------------------\\
        // Button load game
        btnLaunch.setOnAction(actionEvent -> {
            mainStage.show();
            landingStage.hide();
            countdown();
            try {checkSave();} catch (FileNotFoundException e) {e.printStackTrace();}
            lblTotal.setText("You clicked: " + clicked.total);
            lblIncrement.setText("Click Power: " + clicked.increment + "x");
            if (clicked.autoClickBought == 1){
                btnAuto.setVisible(true); btnAuto.setDisable(true); lblAutoIncrement.setText("Auto Click Power: " + clicked.autoIncrement + "x");
                autoClick();
            }
            checkTotal.setCycleCount(Animation.INDEFINITE);
            checkTotal.play();
        });
        // Button to start new game
        btnNewGame.setOnAction(actionEvent -> {
            mainStage.show();
            landingStage.hide();
            autoSave();
            countdown();
            try {createSave(createFile());} catch (FileNotFoundException e) {e.printStackTrace();}
            checkTotal.setCycleCount(Animation.INDEFINITE);
            checkTotal.play();
        });
//------------------------------------------------------// Button events for mainStage\\-------------------------------------------------------------------\\
        // Main click button
        btnClickMe.setOnAction(actionEvent -> {
            lblTotal.setText("You clicked: " + clicked.btnClicked());
            if (clicked.total >= 500) {btnAuto.setVisible(true);}
        });
        // Click upgrade button
        btnUpgrade.setOnAction(actionEvent -> {
            clicked.updateIncrement();
            if (clicked.showUpgrade()) {btnUpgrade.setVisible(true);}
            else {
                btnUpgrade.setVisible(false);
                lblTotal.setText("You clicked: " + clicked.total);
            }
            clicked.total -= clicked.cost;
            lblTotal.setText("You clicked: " + clicked.total);
            clicked.updateCost();
            btnUpgrade.setText(clicked.increment * 2 + "x Click: " + clicked.cost + " clicks");
            btnUpgrade.setVisible(false);
            lblIncrement.setText("Click Power: " + clicked.increment + "x");
            System.out.println("Cost: " + clicked.cost + " " + "Increment: " + clicked.increment);
        });
        // Auto click button
        btnAuto.setOnAction(actionEvent -> {
            clicked.autoClickBought = 1;
            autoClick();
            btnAuto.setDisable(true); btnAuto.setText("Auto click on!");
            lblAutoIncrement.setText("Auto Click Power: " + clicked.autoIncrement + "x");
            btnAuto.setOnMouseClicked(t -> clicked.total -= 500);
        });
        // Auto click upgrade button
        btnAutoUpgrade.setOnAction(actionEvent -> {
            clicked.total -= clicked.autoCost;
            btnAutoUpgrade.setVisible(false);
            clicked.updateAutoCost();
            clicked.updateAutoIncrement();
            lblAutoIncrement.setText("Auto Click Power " + clicked.autoIncrement + "x");
        });
        // Damage button
        btnDamage.setOnAction(actionEvent -> updateHealth());
        // Settings button handler
        btnSettings.setOnAction(actionEvent -> {mainStage.hide();settingsStage.show();});
//---------------------------------------------------//Button events for Settings stage\\------------------------------------------------------------------\\
        // Back button
        btnHome.setOnAction(actionEvent -> {mainStage.show();settingsStage.hide();});
        btnSave.setOnAction(actionEvent -> {try {createSave(createFile());} catch (FileNotFoundException e) {e.printStackTrace();}});
//----------------------------------------------------//Adding nodes to Landing stage\\--------------------------------------------------------------------\\
        landingPane.add(lblLandingTitle, 4, 0, 2, 1); GridPane.setHalignment(lblLandingTitle, HPos.CENTER);
        landingPane.add(lblQuote, 3, 1, 4, 2); GridPane.setHalignment(lblQuote, HPos.LEFT);
        landingPane.add(btnLaunch, 0, 1, 2, 1); GridPane.setHalignment(btnLaunch, HPos.CENTER);
        landingPane.add(btnNewGame, 0, 2, 2, 1); GridPane.setHalignment(btnNewGame, HPos.CENTER);
//-----------------------------------------------------//Adding nodes to Main stage\\----------------------------------------------------------------------\\
        // Add nodes to Maingpane and center
        Maingpane.add(lblTotal, 0,1, 2, 1); GridPane.setHalignment(lblTotal, HPos.CENTER);
        Maingpane.add(lblIncrement, 2,1, 2, 1); GridPane.setHalignment(lblIncrement, HPos.CENTER);
        Maingpane.add(lblAutoIncrement, 4,1, 2, 1); GridPane.setHalignment(lblAutoIncrement, HPos.CENTER);
        Maingpane.add(lblTitle, 4, 0, 2, 1); GridPane.setHalignment(lblTitle, HPos.CENTER);
        Maingpane.add(lblAutoSaveTimer, 8, 0, 2, 1); GridPane.setHalignment(lblAutoSaveTimer, HPos.CENTER);
        Maingpane.add(lblTime, 0, 19, 1, 1); GridPane.setHalignment(lblTime, HPos.CENTER);
        Maingpane.add(lblCountdown, 0, 20, 1, 1); GridPane.setHalignment(lblCountdown, HPos.CENTER);
        Maingpane.add(prgHealthBar, 0, 18, 2, 1); GridPane.setHalignment(prgHealthBar, HPos.CENTER);
        Maingpane.add(btnDamage, 0, 17, 1, 1); GridPane.setHalignment(btnDamage, HPos.CENTER);
        Maingpane.add(btnClickMe, 0, 2, 2, 1); GridPane.setHalignment(btnClickMe, HPos.CENTER);
        Maingpane.add(btnAuto, 4, 2, 2, 1); GridPane.setHalignment(btnAuto, HPos.CENTER);
        Maingpane.add(btnAutoUpgrade, 4, 3, 2, 1); GridPane.setHalignment(btnAutoUpgrade, HPos.CENTER);
        Maingpane.add(btnUpgrade, 2, 2, 2, 1); GridPane.setHalignment(btnUpgrade, HPos.CENTER);
        Maingpane.add(btnSettings, 0, 21); GridPane.setHalignment(btnSettings, HPos.CENTER);
//----------------------------------------------------//Adding nodes to Settings stage\\-------------------------------------------------------------------\\
        // Add nodes to settingsPane and center
        settingsGPane.add(btnHome, 0, 21); GridPane.setHalignment(btnHome, HPos.CENTER);
        settingsGPane.add(lblSettingsTitle, 4, 0, 2, 1); GridPane.setHalignment(lblSettingsTitle, HPos.CENTER);
        settingsGPane.add(btnSave, 0, 1, 2, 1); GridPane.setHalignment(btnSave, HPos.CENTER);
    }
//-----------------------------------------------------------//Methods for game\\--------------------------------------------------------------------------\\
    // Countdown method
    public void countdown(){

        final int[] interval = {30};
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                if(interval[0] > 0)
                {Platform.runLater(() -> lblCountdown.setText("Autosave in: "+ interval[0]));
                    interval[0]--;}
                else countdown();}
        }, 1000,1000);}
    // AutoSave method
    public File autoSave(){
        File autoSaveFile = new File("Saves\\autoSave.txt");
        // Timeline for autosave
        Timeline autoSaveTimer = new Timeline(new KeyFrame(Duration.seconds(30), ev ->{
            try {
                PrintWriter autoOutput = new PrintWriter(autoSaveFile);
                autoOutput.println(clicked.total);
                autoOutput.println(clicked.increment);
                autoOutput.println(clicked.cost);
                autoOutput.println(clicked.autoIncrement);
                autoOutput.println(clicked.autoCost);
                autoOutput.println(clicked.autoClickBought);
                autoOutput.close();
                System.out.println("Saved file!");
            } catch (FileNotFoundException e) {e.printStackTrace();}
        }));
        autoSaveTimer.setCycleCount(Animation.INDEFINITE);
        autoSaveTimer.play();
        return autoSaveFile;
    }
    // Method to create file
    public File createFile(){return new File("Saves\\save.txt");}
    // Create Save method
    public void createSave(File saveData) throws FileNotFoundException {
        PrintWriter output = new PrintWriter(saveData);
        output.println(clicked.total);
        output.println(clicked.increment);
        output.println(clicked.cost);
        output.println(clicked.autoIncrement);
        output.println(clicked.autoCost);
        output.println(clicked.autoClickBought);
        output.close();
    }
    // Load Save method
    public void loadSave(File saveData) throws FileNotFoundException {
        Scanner input = new Scanner(saveData);
        clicked.total = Integer.parseInt(input.next());
        clicked.increment = Integer.parseInt(input.next());
        clicked.cost = Integer.parseInt(input.next());
        clicked.autoIncrement = Integer.parseInt(input.next());
        clicked.autoCost = Integer.parseInt(input.next());
        clicked.autoClickBought = Integer.parseInt(input.next());
        input.close();
    }
    // Check save method
    public boolean checkSave() throws FileNotFoundException {
        File checkAuto = autoSave(); File checkSave = createFile();
        if (checkSave.exists()){
            loadSave(checkSave);
            return true;
        }else if (checkAuto.exists()){
            loadSave(checkAuto);
            return true;
        }else {return false;}
    }
    // Auto click method
    public void autoClick(){
        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(500), ev -> {
            clicked.btnAutoClicked();
            lblTotal.setText("You clicked: " + clicked.total);
            System.out.println("Total: " + clicked.total + "\n");
            System.out.println("Auto cost: " + clicked.autoCost + "\n");
            if (clicked.total >= clicked.cost){btnUpgrade.setVisible(true);}
        }));
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }
    // Quote method
    public void callQuote() throws FileNotFoundException {
        File quote = new File("Resources\\test.txt");
        String result = null;
        Random rand = new Random();
        int n = 0;
        for(Scanner sc = new Scanner(quote); sc.hasNext(); )
        {
            ++n;
            String line = sc.nextLine();
            if(rand.nextInt(n) == 0) result = line;
            lblQuote.setText(result);
        }
    }
    // Health bar method
    public void updateHealth(){
        if (prgHealthBar.getProgress() > 0){
            prgHealthBar.setProgress(prgHealthBar.getProgress() - 1);
            System.out.println("Health: " + prgHealthBar.getProgress());
        } else {
            prgHealthBar.setProgress(10);
            updateHealth();
        }
    }
//--------------------------------------------------------//Class to handle clicks\\-----------------------------------------------------------------------\\
    public static class Clicked {
        // Variables
        int total = 0;
        int increment = 1;
        int cost = 10;
        int autoIncrement = 1;
        int autoCost = 1000;
        int autoClickBought = 0;
        // Add to the total based on the increment value when the main button is clicked
        public int btnClicked(){return total+=increment;}
        // Auto click method to auto click the button
        public void btnAutoClicked(){total += autoIncrement;}
        // Determine if the upgrade button is ready to be shown
        public boolean showUpgrade(){return total >= cost;}
        // Update the cost value of upgrades
        public void updateCost(){cost *= 10;}
        // Update the increment variable
        public void updateIncrement(){increment *= 2;}
        // Update increment value for auto clicker
        public void updateAutoIncrement(){autoIncrement += 1;}
        // Update cost for auto clicker
        public void updateAutoCost(){autoCost *= 2;}
    }
//------------------------------------------------------------//Launch method\\----------------------------------------------------------------------------\\
    public static void main(String[] args) {launch();}
}