module com.example.hahanumbergoup {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires javafx.graphics;

    opens com.example.hahanumbergoup to javafx.fxml;
    exports com.example.hahanumbergoup;
}